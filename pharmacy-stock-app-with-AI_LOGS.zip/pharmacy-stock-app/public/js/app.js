// public/js/app.js
requireSession();

const user = getUser();
document.getElementById('userGreeting').textContent = user ? `Hi, ${user.name}` : '';
document.getElementById('logoutLink').addEventListener('click', (e) => { e.preventDefault(); logout(); });

// ---------------- Inventory table: search + sort + paginate ----------------
let medState = { search: '', sort: 'name', order: 'asc', page: 1, limit: 10 };

async function loadMedicines() {
  const params = new URLSearchParams(medState);
  let result;
  try {
    result = await apiFetch(`/api/medicines?${params}`);
  } catch (err) {
    return;
  }
  const tbody = document.getElementById('medTableBody');
  const emptyEl = document.getElementById('medEmpty');
  tbody.innerHTML = '';
  emptyEl.style.display = result.data.length ? 'none' : 'block';

  for (const m of result.data) {
    const tr = document.createElement('tr');
    const inDate = m.sellable_stock > 0;
    tr.innerHTML = `
      <td>${escapeHtml(m.name)}</td>
      <td>${escapeHtml(m.manufacturer || '')}</td>
      <td>₹${Number(m.unit_price).toFixed(2)}</td>
      <td>${m.sellable_stock}</td>
      <td><span class="tag ${inDate ? 'tag-ok' : 'tag-danger'}">${inDate ? 'In date' : 'Out of date stock'}</span></td>`;
    tbody.appendChild(tr);
  }
  renderPagination(result);
}

function renderPagination(result) {
  const el = document.getElementById('medPagination');
  el.innerHTML = `
    <button id="prevPage" ${result.page <= 1 ? 'disabled' : ''}>&larr; Prev</button>
    <span>Page ${result.page} of ${result.totalPages || 1} (${result.total} total)</span>
    <button id="nextPage" ${result.page >= result.totalPages ? 'disabled' : ''}>Next &rarr;</button>`;
  document.getElementById('prevPage').onclick = () => { medState.page--; loadMedicines(); };
  document.getElementById('nextPage').onclick = () => { medState.page++; loadMedicines(); };
}

let searchDebounce;
document.getElementById('searchInput').addEventListener('input', (e) => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(() => {
    medState.search = e.target.value;
    medState.page = 1;
    loadMedicines();
  }, 300);
});
document.getElementById('sortSelect').addEventListener('change', (e) => { medState.sort = e.target.value; medState.page = 1; loadMedicines(); });
document.getElementById('orderSelect').addEventListener('change', (e) => { medState.order = e.target.value; medState.page = 1; loadMedicines(); });
document.getElementById('limitSelect').addEventListener('change', (e) => { medState.limit = Number(e.target.value); medState.page = 1; loadMedicines(); });

// ---------------- Add medicine ----------------
document.getElementById('addMedicineForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('medMsg');
  try {
    await apiFetch('/api/medicines', {
      method: 'POST',
      body: JSON.stringify({
        name: document.getElementById('medName').value,
        manufacturer: document.getElementById('medManufacturer').value,
        unitPrice: Number(document.getElementById('medPrice').value) || 0,
      }),
    });
    msg.style.color = 'var(--green)';
    msg.textContent = 'Medicine saved.';
    e.target.reset();
    loadMedicines();
  } catch (err) {
    msg.style.color = 'var(--red)';
    msg.textContent = err.message;
  }
});

// ---------------- Add batch ----------------
document.getElementById('addBatchForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('batchMsg');
  try {
    await apiFetch('/api/batches', {
      method: 'POST',
      body: JSON.stringify({
        medicineName: document.getElementById('batchMed').value,
        batchId: document.getElementById('batchId').value,
        quantity: Number(document.getElementById('batchQty').value),
        mfgDate: document.getElementById('batchMfg').value,
        expiryDate: document.getElementById('batchExp').value,
      }),
    });
    msg.style.color = 'var(--green)';
    msg.textContent = 'Batch added.';
    e.target.reset();
    loadMedicines();
    loadAlerts();
  } catch (err) {
    msg.style.color = 'var(--red)';
    msg.textContent = err.message;
  }
});

// ---------------- Dispense ----------------
document.getElementById('dispenseForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const resultEl = document.getElementById('dispResult');
  try {
    const data = await apiFetch('/api/dispense', {
      method: 'POST',
      body: JSON.stringify({
        medicineName: document.getElementById('dispMed').value,
        quantity: Number(document.getElementById('dispQty').value),
      }),
    });
    resultEl.innerHTML = `<div class="success-msg">Dispensed ${data.quantityDispensed} unit(s), FEFO order:</div>
      <ul class="mono">${data.lines.map(l => `<li>${l.quantityTaken} from batch ${escapeHtml(l.batchId)} (expires ${l.expiryDate})</li>`).join('')}</ul>`;
    e.target.reset();
    loadMedicines();
    loadAlerts();
  } catch (err) {
    resultEl.innerHTML = `<div class="error-msg">${escapeHtml(err.message)}</div>`;
  }
});

// ---------------- Alerts: expiring soon + expired ----------------
async function loadAlerts() {
  const days = document.getElementById('expiringDays').value;
  try {
    const expiring = await apiFetch(`/api/alerts/expiring?days=${days}`);
    const body = document.getElementById('expiringBody');
    body.innerHTML = '';
    document.getElementById('expiringEmpty').style.display = expiring.length ? 'none' : 'block';
    for (const b of expiring) {
      const tr = document.createElement('tr');
      const urgent = b.days_left <= 7;
      tr.innerHTML = `<td>${escapeHtml(b.medicine_name)}</td><td class="mono">${escapeHtml(b.batch_id)}</td>
        <td>${b.quantity}</td><td>${b.expiry_date}</td>
        <td><span class="tag ${urgent ? 'tag-danger' : 'tag-warn'}">${b.days_left} day(s)</span></td>`;
      body.appendChild(tr);
    }
  } catch {}

  try {
    const expired = await apiFetch('/api/alerts/expired');
    const body = document.getElementById('expiredBody');
    body.innerHTML = '';
    document.getElementById('expiredEmpty').style.display = expired.length ? 'none' : 'block';
    for (const b of expired) {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${escapeHtml(b.medicine_name)}</td><td class="mono">${escapeHtml(b.batch_id)}</td>
        <td>${b.quantity}</td><td>${b.expiry_date}</td>`;
      body.appendChild(tr);
    }
  } catch {}
}
document.getElementById('expiringDays').addEventListener('change', loadAlerts);

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

loadMedicines();
loadAlerts();
