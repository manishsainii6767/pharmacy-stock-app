// public/js/auth.js
// Tiny shared session helper used by every page that talks to the API.

function saveSession(token, user) {
  localStorage.setItem('sellwell_token', token);
  localStorage.setItem('sellwell_user', JSON.stringify(user));
}

function getToken() {
  return localStorage.getItem('sellwell_token');
}

function getUser() {
  try { return JSON.parse(localStorage.getItem('sellwell_user')); } catch { return null; }
}

function logout() {
  localStorage.removeItem('sellwell_token');
  localStorage.removeItem('sellwell_user');
  window.location.href = 'login.html';
}

/** Redirects to login if there's no session. Call at the top of protected pages. */
function requireSession() {
  if (!getToken()) window.location.href = 'login.html';
}

/** fetch() wrapper that attaches the auth header and handles 401s uniformly. */
async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${getToken()}`,
      ...(options.headers || {}),
    },
  });
  if (res.status === 401) {
    logout();
    throw new Error('Session expired, please log in again.');
  }
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed.');
  return data;
}
