// src/routes/alerts.js
const express = require('express');
const router = express.Router();
const svc = require('../services/pharmacyService');

// GET /api/alerts/expiring?days=30 - batches expiring within N days (not yet expired)
router.get('/expiring', (req, res) => {
  const days = Number(req.query.days || 30);
  res.json(svc.getBatchesExpiringSoon(days));
});

// GET /api/alerts/expired - batches already past expiry (write-off list)
router.get('/expired', (req, res) => {
  res.json(svc.getExpiredBatches());
});

module.exports = router;
