// src/routes/batches.js
const express = require('express');
const router = express.Router();
const svc = require('../services/pharmacyService');

// GET /api/batches?medicine=&sort=&order=&page=&limit=
router.get('/', (req, res) => {
  const { medicine, sort = 'expiry_date', order = 'asc', page = 1, limit = 10 } = req.query;
  const result = svc.listBatches({ medicineName: medicine, sort, order, page: Number(page), limit: Number(limit) });
  res.json(result);
});

// POST /api/batches - add a new stock batch
router.post('/', (req, res) => {
  try {
    const { medicineName, batchId, quantity, mfgDate, expiryDate } = req.body || {};
    const batch = svc.addBatch({ medicineName, batchId, quantity: Number(quantity), mfgDate, expiryDate });
    res.status(201).json(batch);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

module.exports = router;
