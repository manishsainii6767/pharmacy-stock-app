// src/routes/medicines.js
const express = require('express');
const router = express.Router();
const svc = require('../services/pharmacyService');

// GET /api/medicines?search=&sort=&order=&page=&limit=
// Paginated, searchable (by name), sortable list with computed sellable stock.
router.get('/', (req, res) => {
  const { search = '', sort = 'name', order = 'asc', page = 1, limit = 10 } = req.query;
  const result = svc.listMedicines({ search, sort, order, page: Number(page), limit: Number(limit) });
  res.json(result);
});

// POST /api/medicines - add/update a medicine in the catalog
router.post('/', (req, res) => {
  try {
    const { name, manufacturer, unitPrice } = req.body || {};
    if (!name || !name.trim()) return res.status(400).json({ error: 'name is required.' });
    const med = svc.addMedicine({ name, manufacturer, unitPrice });
    res.status(201).json(med);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

// GET /api/medicines/:name/stock - sellable (in-date) stock count
router.get('/:name/stock', (req, res) => {
  res.json({ medicine: req.params.name, sellableStock: svc.getSellableStock(req.params.name) });
});

// GET /api/medicines/:name/in-date - "do we have X in date?"
router.get('/:name/in-date', (req, res) => {
  res.json({ medicine: req.params.name, inDate: svc.isInDate(req.params.name) });
});

module.exports = router;
