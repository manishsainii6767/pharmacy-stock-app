// src/routes/dispense.js
const express = require('express');
const router = express.Router();
const svc = require('../services/pharmacyService');

// POST /api/dispense - dispense stock FEFO (First-Expiry-First-Out).
// Transactional: either the full quantity is dispensed, or nothing is (409).
router.post('/', (req, res) => {
  try {
    const { medicineName, quantity } = req.body || {};
    const lines = svc.dispense(medicineName, Number(quantity));
    res.json({ medicine: medicineName, quantityDispensed: Number(quantity), lines });
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

module.exports = router;
