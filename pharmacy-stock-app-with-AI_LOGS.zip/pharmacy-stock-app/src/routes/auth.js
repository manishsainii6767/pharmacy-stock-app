// src/routes/auth.js
const express = require('express');
const router = express.Router();
const { register, login } = require('../auth');

// POST /api/auth/register - create a new user account, returns a JWT
router.post('/register', (req, res) => {
  try {
    const result = register(req.body || {});
    res.status(201).json(result);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

// POST /api/auth/login - authenticate, returns a JWT
router.post('/login', (req, res) => {
  try {
    const result = login(req.body || {});
    res.json(result);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

module.exports = router;
