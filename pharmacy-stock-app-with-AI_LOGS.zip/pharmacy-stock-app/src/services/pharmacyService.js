// src/services/pharmacyService.js
// Core business logic: FEFO (First-Expiry-First-Out) dispensing, stock
// queries, and expiry alerts. Kept separate from the Express routes so
// the rules can be tested / reused independent of HTTP.
const db = require('../db');

function today() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD, comparable as text
}

function getMedicineByName(name) {
  return db.prepare('SELECT * FROM medicines WHERE name = ?').get(name);
}

function addMedicine({ name, manufacturer, unitPrice }) {
  const existing = getMedicineByName(name);
  if (existing) {
    db.prepare('UPDATE medicines SET manufacturer = ?, unit_price = ? WHERE id = ?')
      .run(manufacturer || existing.manufacturer, unitPrice ?? existing.unit_price, existing.id);
    return getMedicineByName(name);
  }
  db.prepare('INSERT INTO medicines (name, manufacturer, unit_price) VALUES (?, ?, ?)')
    .run(name, manufacturer || 'Unknown', unitPrice || 0);
  return getMedicineByName(name);
}

function addBatch({ medicineName, batchId, quantity, mfgDate, expiryDate }) {
  if (!medicineName || !medicineName.trim()) throw httpError(400, 'Medicine name is required.');
  if (!batchId || !batchId.trim()) throw httpError(400, 'Batch ID is required.');
  if (!Number.isInteger(quantity) || quantity <= 0) throw httpError(400, 'Quantity must be a positive integer.');
  if (!mfgDate || !expiryDate) throw httpError(400, 'mfgDate and expiryDate are required (YYYY-MM-DD).');
  if (expiryDate < mfgDate) throw httpError(400, 'Expiry date cannot be before manufacturing date.');

  const dup = db.prepare('SELECT id FROM batches WHERE batch_id = ?').get(batchId);
  if (dup) throw httpError(409, `Batch ID '${batchId}' already exists.`);

  let med = getMedicineByName(medicineName);
  if (!med) med = addMedicine({ name: medicineName, manufacturer: 'Unknown', unitPrice: 0 });

  db.prepare(`INSERT INTO batches (batch_id, medicine_id, quantity, mfg_date, expiry_date)
              VALUES (?, ?, ?, ?, ?)`)
    .run(batchId, med.id, quantity, mfgDate, expiryDate);
  return { medicine: med.name, batchId, quantity, mfgDate, expiryDate };
}

/** Total sellable (non-expired) stock for a medicine. */
function getSellableStock(medicineName) {
  const med = getMedicineByName(medicineName);
  if (!med) return 0;
  const row = db.prepare(
    `SELECT COALESCE(SUM(quantity), 0) AS total FROM batches
     WHERE medicine_id = ? AND expiry_date >= ?`
  ).get(med.id, today());
  return row.total;
}

function isInDate(medicineName) {
  return getSellableStock(medicineName) > 0;
}

/**
 * FEFO dispense: pulls from the earliest-expiring, non-expired batches first.
 * Transactional (all-or-nothing) - if in-date stock can't cover the request,
 * nothing is deducted and a 409 is thrown.
 */
function dispense(medicineName, requestedQty) {
  if (!Number.isInteger(requestedQty) || requestedQty <= 0) {
    throw httpError(400, 'Quantity must be a positive integer.');
  }
  const med = getMedicineByName(medicineName);
  if (!med) throw httpError(404, `Medicine not found: '${medicineName}'`);

  const candidates = db.prepare(
    `SELECT * FROM batches WHERE medicine_id = ? AND expiry_date >= ? AND quantity > 0
     ORDER BY expiry_date ASC, batch_id ASC`
  ).all(med.id, today());

  const totalAvailable = candidates.reduce((sum, b) => sum + b.quantity, 0);
  if (totalAvailable < requestedQty) {
    throw httpError(409, `Insufficient in-date stock for '${medicineName}': requested ${requestedQty}, only ${totalAvailable} available.`);
  }

  const lines = [];
  let remaining = requestedQty;
  const updateStmt = db.prepare('UPDATE batches SET quantity = ? WHERE id = ?');
  const logStmt = db.prepare(
    'INSERT INTO transactions (medicine_id, batch_id, quantity_taken) VALUES (?, ?, ?)'
  );

  db.exec('BEGIN');
  try {
    for (const b of candidates) {
      if (remaining === 0) break;
      const take = Math.min(remaining, b.quantity);
      updateStmt.run(b.quantity - take, b.id);
      logStmt.run(med.id, b.batch_id, take);
      lines.push({ batchId: b.batch_id, quantityTaken: take, expiryDate: b.expiry_date });
      remaining -= take;
    }
    db.exec('COMMIT');
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
  return lines;
}

/** Paginated, searchable, sortable medicine list with computed sellable stock. */
function listMedicines({ search = '', sort = 'name', order = 'asc', page = 1, limit = 10 }) {
  const allowedSort = ['name', 'manufacturer', 'unit_price', 'sellable_stock'];
  const sortCol = allowedSort.includes(sort) ? sort : 'name';
  const sortOrder = order.toLowerCase() === 'desc' ? 'DESC' : 'ASC';
  const offset = (Math.max(1, page) - 1) * limit;

  const rows = db.prepare(`
    SELECT m.id, m.name, m.manufacturer, m.unit_price,
      COALESCE((SELECT SUM(quantity) FROM batches WHERE medicine_id = m.id AND expiry_date >= ?), 0) AS sellable_stock
    FROM medicines m
    WHERE m.name LIKE ?
    ORDER BY ${sortCol} ${sortOrder}
    LIMIT ? OFFSET ?
  `).all(today(), `%${search}%`, limit, offset);

  const totalRow = db.prepare(
    'SELECT COUNT(*) AS count FROM medicines WHERE name LIKE ?'
  ).get(`%${search}%`);

  return {
    data: rows,
    page: Number(page),
    limit: Number(limit),
    total: totalRow.count,
    totalPages: Math.ceil(totalRow.count / limit),
  };
}

/** Paginated, sortable batch list, optionally filtered to one medicine. */
function listBatches({ medicineName, sort = 'expiry_date', order = 'asc', page = 1, limit = 10 }) {
  const allowedSort = ['expiry_date', 'mfg_date', 'quantity', 'batch_id'];
  const sortCol = allowedSort.includes(sort) ? sort : 'expiry_date';
  const sortOrder = order.toLowerCase() === 'desc' ? 'DESC' : 'ASC';
  const offset = (Math.max(1, page) - 1) * limit;

  let where = '1=1';
  const params = [];
  if (medicineName) {
    const med = getMedicineByName(medicineName);
    where = 'medicine_id = ?';
    params.push(med ? med.id : -1);
  }

  const rows = db.prepare(`
    SELECT b.*, m.name AS medicine_name,
      (b.expiry_date < ?) AS is_expired
    FROM batches b JOIN medicines m ON m.id = b.medicine_id
    WHERE ${where}
    ORDER BY ${sortCol} ${sortOrder}
    LIMIT ? OFFSET ?
  `).all(today(), ...params, limit, offset);

  const totalRow = db.prepare(`SELECT COUNT(*) AS count FROM batches b WHERE ${where}`).get(...params);

  return {
    data: rows,
    page: Number(page),
    limit: Number(limit),
    total: totalRow.count,
    totalPages: Math.ceil(totalRow.count / limit),
  };
}

function getBatchesExpiringSoon(withinDays = 30) {
  const now = new Date();
  const future = new Date(now);
  future.setDate(future.getDate() + Number(withinDays));
  const futureStr = future.toISOString().slice(0, 10);

  return db.prepare(`
    SELECT b.*, m.name AS medicine_name,
      CAST(julianday(b.expiry_date) - julianday(?) AS INTEGER) AS days_left
    FROM batches b JOIN medicines m ON m.id = b.medicine_id
    WHERE b.expiry_date >= ? AND b.expiry_date <= ?
    ORDER BY b.expiry_date ASC
  `).all(today(), today(), futureStr);
}

function getExpiredBatches() {
  return db.prepare(`
    SELECT b.*, m.name AS medicine_name
    FROM batches b JOIN medicines m ON m.id = b.medicine_id
    WHERE b.expiry_date < ?
    ORDER BY b.expiry_date ASC
  `).all(today());
}

function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

module.exports = {
  addMedicine, addBatch, getMedicineByName,
  getSellableStock, isInDate, dispense,
  listMedicines, listBatches,
  getBatchesExpiringSoon, getExpiredBatches,
};
